function alertmessage() {
    var couponNumber = document.getElementById("coupon_number").value;
    if (couponNumber.trim() !== ""){
        alert("Coupon " + couponNumber + " has been applied successfully!");
    } else {
        alert("Please enter a valid coupon number.");
    }
    event.preventDefault();
}


function alertmessage_sub() {
    var email = document.getElementById("subscription").value;
    if (email.trim() !== "") {
        alert(email + " is added for our newsletter!");
    } else {
        alert("Please enter a valid email");
    }
    event.preventDefault();
}