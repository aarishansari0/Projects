<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hour_page</title>
</head>
<body>
    <form action='time_connect.php' method="POST">
        <label>start time : </label>
        <select name="start_hour" id="start_hour">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
        </select>
        <label>:</label>
        <select name="start_min" id="start_min">
            <option value="0">00</option>
            <option value="15">15</option>
            <option value="30">30</option>
            <option value="45">45</option>
        </select>
        <select name="start_AM_PM" id="start_AM_PM">
            <option value="AM">AM</option>
            <option value="PM">PM</option>
        </select><br>
        <label>end time : </label>
        <select name="end_hour" id="end_hour">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
        </select>
        <label>:</label>
        <select name="end_min" id="end_min">
            <option value="0">00</option>
            <option value="15">15</option>
            <option value="30">30</option>
            <option value="45">45</option>
        </select>
        <select name="end_AM_PM" id="end_AM_PM">
            <option value="AM">AM</option>
            <option value="PM">PM</option>
        </select>
        <br>
        <input type="submit" id="hour_submit" name="hour_submit">
    </form>
</body>
</html>