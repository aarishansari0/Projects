<?php
session_start();
$servername = "localhost";
$username = "root";
$pass = "";
$dbname = "test1";

$conn=mysqli_connect($servername,$username,$pass,$dbname) or die("connection failed" .mysqli_connect_error());

if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])){
if (isset($_POST['name']) && isset($_POST['password']) && isset($_POST['userid'])){
$name= $_POST['name'];
$userid= $_POST['userid'];
$password= $_POST['password'];

$sql = "INSERT INTO `users`(`userid`, `name`, `pasword`) VALUES ($userid,'$name','$password')";
$query = mysqli_query($conn,$sql);
if($query){
    echo "succ";
}
else{
    echo "fail";
}
}}

if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit2'])){
    if (isset($_POST['name']) && isset($_POST['password']) && isset($_POST['userid'])){
    $name= $_POST['name'];
    $userid= $_POST['userid'];
    $password= $_POST['password'];
    
    $sql = "SELECT * FROM `users` WHERE 'userid'=$userid and 'name'='$name' and 'pasword'='$password'";
    $query = mysqli_query($conn,$sql);
    if($query){
        echo "logged in<br>";
        $_SESSION['userid']=$userid;
        $_SESSION['name']=$name;
        $_SESSION['password']=$password;
        header("Location: hour_page.php");
        exit;
    }
    else{
        echo "not logged";
    }
    }}

?>