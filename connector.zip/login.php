<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login form</title>
</head>
<body>
    <form action='connector.php' method="POST">
        <label>user id</label>
        <input type="text" name="userid" id="userid" required><br>
        <label>name</label>
        <input type="text" name="name" id="name" required><br>
        <label>password</label>
        <input type="text" name="password" id="password" required><br>
        <input type="submit" id="submit" name="submit">
        <input type="submit" id="submit2" name="submit2">
    </form>
</body>
</html>