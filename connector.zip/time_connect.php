<?php
session_start();
$servername = "localhost";
$username = "root";
$pass = "";
$dbname = "test1";

$conn=mysqli_connect($servername,$username,$pass,$dbname) or die("connection failed" .mysqli_connect_error());

if ($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['hour_submit']))
{
$s_hour=(int) $_POST['start_hour'];
$s_min=(int) $_POST['start_min'];
$s_AM_PM= $_POST['start_AM_PM'];
$e_hour=(int) $_POST['end_hour'];
$e_min=(int) $_POST['end_min'];
$e_AM_PM= $_POST['end_AM_PM'];
if($s_AM_PM=="PM"){$s_hour+=12;}
if($e_AM_PM=="PM"){$e_hour+=12;}
$hour = $e_hour-$s_hour;
if($s_min>$e_min){
    $hour-=1;
    $e_min+= 60;
}
$min=$e_min-$s_min;
$min=$min/60;
$hour+=$min;

$name=$_SESSION['name'];
$userid=$_SESSION['userid'];
$password=$_SESSION['password'];
$sql = "SELECT * FROM `users` WHERE 'userid'=$userid and 'name'='$name' and 'pasword'='$password'";
$query = mysqli_query($conn,$sql);
if($query){
    $sql = "UPDATE users SET worked_hours=worked_hours+$hour WHERE userid=$userid;";
    $query = mysqli_query($conn,$sql);
    echo "submitted";}
else{
    echo "fail";
}
}

?>