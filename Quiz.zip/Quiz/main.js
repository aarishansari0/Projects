

let questions = [
    {
        question: "What is the capital of France?",
        options: ["Paris", "London", "Berlin", "Rome"],
        answer: 0
    },
    {
        question: "What is the largest planet in our solar system?",
        options: ["Earth", "Saturn", "Jupiter", "Uranus"],
        answer: 2
    },
    // Add more questions here
];

let currentQuestion = 0;
let timer = 60;
let score = 0;
let incorrectAnswers = [];

// Initialize the quiz
function initializeQuiz() {
    document.getElementById("question").innerText = questions[currentQuestion].question;
    document.getElementById("options").innerHTML = "";
    questions[currentQuestion].options.forEach((option, index) => {
        let li = document.createElement("li");
        let input = document.createElement("input");
        input.type = "radio";
        input.id = `option${index + 1}`;
        input.name = "answer";
        let label = document.createElement("label");
        label.htmlFor = input.id;
        label.innerText = option;
        li.appendChild(input);
        li.appendChild(label);
        document.getElementById("options").appendChild(li);
    });
    document.getElementById("timer").innerText = `Time: ${timer} seconds`;
}

// Start the timer
let interval = setInterval(() => {
    timer--;
    document.getElementById("timer").innerText = `Time: ${timer} seconds`;
    if (timer <= 0) {
        clearInterval(interval);
        alert("Time's up! Your score is " + score + "/" + questions.length);
        displayResults();
    }
}, 1000);

// Check the answer when the submit button is clicked
document.getElementById("submit").addEventListener("click", checkAnswer);

// Function to check the selected answer
function checkAnswer() {
    let selectedOption = document.querySelector("input[name='answer']:checked");
    if (selectedOption) {
        let answerIndex = questions[currentQuestion].options.indexOf(selectedOption.nextSibling.textContent);
        if (answerIndex !== questions[currentQuestion].answer) {
            incorrectAnswers.push(questions[currentQuestion].question);
        }
        if (answerIndex === questions[currentQuestion].answer) {
            score++;
        }
        currentQuestion++;
        if (currentQuestion < questions.length) {
            initializeQuiz();
        } else {
            clearInterval(interval);
            displayResults();
        }
    } else {
        alert("Please select an answer before submitting.");
    }
}

// Function to display the results
function displayResults() {
    let resultMessage = `Your score is ${score} out of ${questions.length}.`;
    if (incorrectAnswers.length > 0) {
        resultMessage += `\nYou got the following questions wrong:`;
        incorrectAnswers.forEach((question, index) => {
            resultMessage += `\n${index + 1}. ${question}`;
        });
    }
    alert(resultMessage);
    resetQuiz();
}

// Function to reset the quiz
function resetQuiz() {
    currentQuestion = 0;
    score = 0;
    timer = 60;
    incorrectAnswers = [];
    initializeQuiz();
}

// Initialize the quiz on page load
initializeQuiz();