import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
lr=LinearRegression()
from sklearn import *

stat="Attack"
drop_stat= "Defense"
df =pd.read_csv("pokemon.csv")
x= df.drop(["Legendary","Generation","#","Name","Type 1","Type 2",stat,drop_stat], axis=1)
y= df[[stat]]

x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2)
lr.fit(x_train,y_train)
accuracy = lr.score(x_test,y_test)

print("accuracy of predicting the stat", stat, "after dropping", drop_stat)
print("is", 100*accuracy,"%")



