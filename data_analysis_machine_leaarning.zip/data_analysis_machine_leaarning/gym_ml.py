import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LinearRegression

from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report

#initialization
model= KNeighborsClassifier(n_neighbors=6)
lr=LinearRegression()
df =pd.read_csv("gym_dataset.csv")

#K Nearest Neighbor classification
x= df.drop(["Age", "Gender", "Workout_Type"],axis=1)
y=df[["Gender"]].squeeze()
x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2)

model.fit(x_train,y_train)
pred= model.predict(x_test)
accuracy= accuracy_score(y_test, pred)
print("accuracy  for predicting gender: "+str(round(accuracy*100,2)))
print("\n"+classification_report(y_test , pred))


#linear regressions
col="Weight (kg)"
x= df.drop(["Age","Gender","Workout_Type","Height (m)", col],axis=1)
y= df[["Weight (kg)"]]

x_train, x_test, y_train, y_test = train_test_split(x,y, test_size=0.2)
lr.fit(x_train,y_train)
accuracy = lr.score(x_test,y_test)

print(f"accuracy for predictng the {col} from the rest of the data {accuracy}\n")
