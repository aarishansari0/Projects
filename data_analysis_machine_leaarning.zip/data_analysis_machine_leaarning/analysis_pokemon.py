import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df= pd.read_csv("pokemon.csv")

stats=["HP","Attack","Defense","Sp. Atk","Sp. Def","Speed"]

#gives an overview on those stats
print(df.describe())

#Shows the individual stats increase as total increases
for i in range(len(stats)):
    df.plot(
        kind="scatter",
        x="Total",
        y=stats[i],
        color="blue"
        )
    plt.title(f"{stats[i]} vs total")
    plt.show()

#distriution of stats in a pue graph
pie=df.sum(axis=0, skipna=True,numeric_only=True)
pie.drop(["Legendary", "Total", "Generation", "#"],inplace=True)
plt.title("stats distribution")
pie.plot(kind='pie', y='Total')
plt.show()



